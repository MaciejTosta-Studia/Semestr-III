dc = {'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h', 'i': 'j', 'k': 'l', 'm': 'n'}

print(list(dc.keys()))